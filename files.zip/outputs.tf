output "repository_id" {
  description = "ID do repositório Dataform"
  value       = google_dataform_repository.repository.id
}

output "repository_name" {
  description = "Nome do repositório Dataform"
  value       = google_dataform_repository.repository.name
}

output "service_account_email" {
  description = "E-mail da Service Account criada"
  value       = google_service_account.dataform_sa.email
}

output "service_account_id" {
  description = "ID único da Service Account"
  value       = google_service_account.dataform_sa.unique_id
}
