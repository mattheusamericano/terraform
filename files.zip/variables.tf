variable "project_id" {
  description = "ID do projeto GCP"
  type        = string
}

variable "region" {
  description = "Região do repositório Dataform"
  type        = string
  default     = "us-central1"
}

variable "repository_name" {
  description = "Nome do repositório Dataform"
  type        = string
}

variable "display_name" {
  description = "Nome de exibição do repositório"
  type        = string
  default     = ""
}

variable "git_url" {
  description = "URL do repositório Git remoto"
  type        = string
}

variable "git_default_branch" {
  description = "Branch padrão do repositório Git"
  type        = string
  default     = "main"
}

variable "git_secret_version" {
  description = "Versão do Secret Manager com o token de autenticação Git"
  type        = string
}

variable "service_account_id" {
  description = "ID da Service Account do Dataform (sem @project.iam.gserviceaccount.com)"
  type        = string
  default     = "sa-dataform"
}

variable "labels" {
  description = "Labels aplicadas ao repositório"
  type        = map(string)
  default     = {}
}
