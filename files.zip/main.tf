############################
# Dataform Repository Module
############################

resource "google_dataform_repository" "repository" {
  provider = google-beta

  project  = var.project_id
  region   = var.region
  name     = var.repository_name

  display_name = var.display_name

  git_remote_settings {
    url                                 = var.git_url
    default_branch                      = var.git_default_branch
    authentication_token_secret_version = var.git_secret_version
  }

  workspace_compilation_overrides {
    default_database = var.project_id
  }

  labels = var.labels
}

############################
# Service Account
############################

resource "google_service_account" "dataform_sa" {
  project      = var.project_id
  account_id   = var.service_account_id
  display_name = "Dataform Service Account"
  description  = "Service Account used by Dataform to access BigQuery and other GCP resources"
}

############################
# IAM Bindings
############################

# BigQuery Data Editor - leitura e escrita em tabelas
resource "google_project_iam_member" "bq_data_editor" {
  project = var.project_id
  role    = "roles/bigquery.dataEditor"
  member  = "serviceAccount:${google_service_account.dataform_sa.email}"
}

# BigQuery Job User - executar jobs de query
resource "google_project_iam_member" "bq_job_user" {
  project = var.project_id
  role    = "roles/bigquery.jobUser"
  member  = "serviceAccount:${google_service_account.dataform_sa.email}"
}

# Secret Manager Secret Accessor - acessar o token do Git
resource "google_project_iam_member" "secret_accessor" {
  project = var.project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${google_service_account.dataform_sa.email}"
}

# Dataform Editor - gerenciar workspaces e compilações
resource "google_project_iam_member" "dataform_editor" {
  project = var.project_id
  role    = "roles/dataform.editor"
  member  = "serviceAccount:${google_service_account.dataform_sa.email}"
}

############################
# Vincular SA ao repositório
############################

resource "google_dataform_repository_iam_member" "sa_repository_admin" {
  provider   = google-beta
  project    = var.project_id
  region     = var.region
  repository = google_dataform_repository.repository.name
  role       = "roles/dataform.admin"
  member     = "serviceAccount:${google_service_account.dataform_sa.email}"
}
